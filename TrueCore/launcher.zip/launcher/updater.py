import requests
import zipfile
import os
import io
import shutil
import sys

from launcher_logging import log


# -------------------------------------------------
# UPDATE SOURCE
# -------------------------------------------------

UPDATE_URL = "https://raw.githubusercontent.com/betteryourpractice/truecore-updates/refs/heads/main/version.json"

ENGINE_DIR = "engine"


# -------------------------------------------------
# CHECK FOR UPDATES
# -------------------------------------------------

def check_updates():

    try:

        r = requests.get(UPDATE_URL, timeout=5)

        data = r.json()

        return data

    except Exception as e:

        log(f"Update check failed: {e}")

        return None


# -------------------------------------------------
# DOWNLOAD UPDATE
# -------------------------------------------------

def download_update(download_url):

    try:

        log("Downloading update...")

        r = requests.get(download_url)

        return io.BytesIO(r.content)

    except Exception as e:

        log(f"Download failed: {e}")

        return None


# -------------------------------------------------
# INSTALL UPDATE
# -------------------------------------------------

def install_update(zip_data):

    try:

        log("Installing update...")

        base_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.getcwd()

        engine_path = os.path.join(base_dir, ENGINE_DIR)

        os.makedirs(engine_path, exist_ok=True)

        # remove old engine versions
        for file in os.listdir(engine_path):

            if file.lower().endswith(".exe"):
                os.remove(os.path.join(engine_path, file))

        # extract new engine
        with zipfile.ZipFile(zip_data) as z:

            z.extractall(engine_path)

        log("Update installed successfully")

        return True

    except Exception as e:

        log(f"Update install failed: {e}")

        return False