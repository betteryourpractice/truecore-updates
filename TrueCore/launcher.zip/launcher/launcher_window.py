from PySide6.QtWidgets import (
    QWidget, QLabel, QPushButton, QTextEdit,
    QLineEdit, QVBoxLayout, QHBoxLayout
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap

import subprocess
import os
import sys

from launcher_logging import log
from updater import check_updates, download_update, install_update


ENGINE_DIR = "engine"


# -------------------------------------------------
# RESOURCE PATH (FOR PYINSTALLER)
# -------------------------------------------------

def resource_path(relative):

    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative)

    return os.path.join(os.path.abspath("."), relative)


# -------------------------------------------------
# FIND ENGINE EXECUTABLE
# -------------------------------------------------

def find_engine():

    base_dir = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.getcwd()

    engine_dir = os.path.join(base_dir, ENGINE_DIR)

    if not os.path.exists(engine_dir):
        return None

    engines = []

    for file in os.listdir(engine_dir):

        if file.lower().startswith("truecore") and file.lower().endswith(".exe"):

            engines.append(os.path.join(engine_dir, file))

    if not engines:
        return None

    engines.sort(reverse=True)

    return engines[0]


# -------------------------------------------------
# LAUNCHER WINDOW
# -------------------------------------------------

class LauncherWindow(QWidget):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("TrueCore Launcher")
        self.resize(1000, 600)

        main_layout = QVBoxLayout()

        # --------------------------------
        # HEADER
        # --------------------------------

        header_layout = QHBoxLayout()

        logo = QLabel()

        pix = QPixmap(resource_path("launcher/assets/truecore_logo.png"))

        logo.setPixmap(pix.scaled(180, 60, Qt.KeepAspectRatio, Qt.SmoothTransformation))

        header_layout.addWidget(logo)

        version_layout = QVBoxLayout()

        self.server_version = QLabel("Server v?")
        self.launcher_version = QLabel("Launcher v1.0")

        version_layout.addWidget(self.server_version)
        version_layout.addWidget(self.launcher_version)

        header_layout.addStretch()
        header_layout.addLayout(version_layout)

        main_layout.addLayout(header_layout)

        # --------------------------------
        # CONTENT AREA
        # --------------------------------

        content_layout = QHBoxLayout()

        # NEWS PANEL
        news_layout = QVBoxLayout()

        news_title = QLabel("News / Updates")

        self.news_box = QTextEdit()
        self.news_box.setReadOnly(True)

        self.news_box.setText(
            "TrueCore Update\n\n"
            "- Improved packet extraction\n"
            "- Faster ICD detection\n"
            "- New launcher system\n"
        )

        news_layout.addWidget(news_title)
        news_layout.addWidget(self.news_box)

        # --------------------------------
        # LOGIN PANEL
        # --------------------------------

        login_layout = QVBoxLayout()

        login_title = QLabel("Sign In")

        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")

        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.Password)

        self.play_button = QPushButton("Launch TrueCore")
        self.play_button.clicked.connect(self.launch_engine)

        login_layout.addWidget(login_title)
        login_layout.addWidget(self.username)
        login_layout.addWidget(self.password)
        login_layout.addStretch()
        login_layout.addWidget(self.play_button)

        content_layout.addLayout(news_layout, 3)
        content_layout.addLayout(login_layout, 1)

        main_layout.addLayout(content_layout)

        # --------------------------------
        # FOOTER BUTTONS
        # --------------------------------

        footer_layout = QHBoxLayout()

        footer_layout.addWidget(QPushButton("Website"))
        footer_layout.addWidget(QPushButton("Blog"))
        footer_layout.addWidget(QPushButton("Docs"))
        footer_layout.addWidget(QPushButton("Support"))
        footer_layout.addWidget(QPushButton("Report Issue"))

        main_layout.addLayout(footer_layout)

        self.setLayout(main_layout)

        # --------------------------------
        # RUN AUTO UPDATE
        # --------------------------------

        self.auto_update()

    # -------------------------------------------------
    # AUTO UPDATE CHECK
    # -------------------------------------------------

    def auto_update(self):

        self.news_box.append("\nChecking for updates...")

        update_data = check_updates()

        if update_data is None:

            self.news_box.append("Update server unreachable.")
            return

        server_version = update_data.get("version")

        if server_version:
            self.server_version.setText(f"Server v{server_version}")

        download_url = update_data.get("download")

        if not download_url:

            self.news_box.append("Invalid update configuration.")
            return

        self.news_box.append(f"Latest version: {server_version}")

        self.news_box.append("Downloading update...")

        zip_data = download_update(download_url)

        if zip_data is None:

            self.news_box.append("Download failed.")
            return

        success = install_update(zip_data)

        if success:

            self.news_box.append("Update installed successfully.")

        else:

            self.news_box.append("Update install failed.")

    # -------------------------------------------------
    # ENGINE LAUNCH
    # -------------------------------------------------

    def launch_engine(self):

        engine = find_engine()

        if engine is None:

            log("No engine found in engine folder.")

            self.news_box.append("\nEngine not found. Please update.")

            return

        try:

            log(f"Launching TrueCore engine: {engine}")

            subprocess.Popen(engine)

            self.close()

        except Exception as e:

            log(f"Engine launch failed: {e}")

            self.news_box.append(f"\nEngine launch failed: {e}")