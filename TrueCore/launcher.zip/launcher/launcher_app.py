import os
import sys
from PySide6.QtWidgets import QApplication

# -------------------------------------------------
# FIX IMPORT PATH FOR PYINSTALLER
# -------------------------------------------------

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

# now Python can find the other launcher files
from TrueCore.launcher.launcher_window import LauncherWindow


def resource_path(relative):

    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative)

    return os.path.join(os.path.abspath("."), relative)


def start_launcher():

    app = QApplication(sys.argv)

    app.setApplicationName("TrueCore Launcher")

    # --------------------------------
    # LOAD STYLESHEET
    # --------------------------------

    try:

        style_path = resource_path("launcher/assets/launcher_style.qss")

        with open(style_path) as f:
            app.setStyleSheet(f.read())

    except Exception as e:

        print(f"Launcher style failed to load: {e}")

    # --------------------------------
    # START WINDOW
    # --------------------------------

    window = LauncherWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":

    start_launcher()